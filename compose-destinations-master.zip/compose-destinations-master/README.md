# compose-destinations
Jetpack Compose app that uses Compose Destinations API to navigate through screens more effectively

**Compose Destinations**

<img src="https://github.com/raheemadamboev/compose-destinations/blob/master/jetpack-compose-banner.png" />

<a href="https://github.com/raheemadamboev/compose-destinations/blob/master/app-debug.apk">Download demo</a>
